# AgriSense AI

An evidence-first mandi market intelligence app that audits imported AGMARKNET data and provides forecasts, seasonal analysis, risk and opportunity comparisons, hypothetical processing scenarios, and sourced policy records.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/agrisense-ai/` — React/Vite web app and analysis pages
- `artifacts/api-server/src/routes/agrisense.ts` — AgriSense API endpoints
- `artifacts/api-server/src/lib/agri-analytics.ts` — reusable market analytics and marked illustrative preview data
- `lib/api-spec/openapi.yaml` — source-of-truth API contract
- `lib/db/src/schema/` — PostgreSQL schemas for imported observations and policy records
- `deploy/linuxone/` — OCI containers and OpenShift deployment files for IBM LinuxONE

## Architecture decisions

- Imported observations are normalized to one dataset-wide price unit; mixed-unit imports are rejected rather than silently compared.
- With no imported AGMARKNET rows, analyses use generated illustrative data and mark it as such; preview values are not real market quotes.
- Crop opportunity rankings use price evidence and coverage only. Processing scenarios are user-entered assumptions, not profitability estimates.
- The IBM LinuxONE deployment target is Red Hat OpenShift Container Platform on `s390x`; Replit remains the development and preview environment.

## Product

- Import and audit AGMARKNET CSV observations with configurable column mapping
- Explore mandi price forecasts, seasonality, market risk, and crop opportunities
- Compare lagged prices only when both real commodity series have sufficient history
- Calculate hypothetical processing gross margins and track sourced MSP/policy records
- Use English, Hindi, or Kannada UI copy and an evidence-aware rule-based assistant

## User preferences

- Build for a portable IBM LinuxONE-compatible deployment target.

## Gotchas

- After changing `lib/api-spec/openapi.yaml`, run `pnpm --filter @workspace/api-spec run codegen`.
- Imported observations use calendar dates and one consistent price unit; do not infer or translate units, dates, or source commodity names.
- Preview rows are generated illustrations; do not describe them as official AGMARKNET data.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
