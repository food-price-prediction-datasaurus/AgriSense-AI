# AgriSense AI on IBM LinuxONE

AgriSense is developed as a Node.js API and a static React web client. The OCI
containers use standard Node.js runtime images so they can be built for
`linux/s390x` and deployed to Red Hat OpenShift Container Platform on IBM
LinuxONE. Replit remains the development and preview environment; this directory
provides the portable deployment path.

## Build images for LinuxONE

From the repository root, with Docker Buildx and access to an image registry:

```sh
docker buildx build --platform linux/s390x \
  -f deploy/linuxone/Containerfile.api \
  -t image-registry.example.com/agrisense/agrisense-api:latest \
  --push .

docker buildx build --platform linux/s390x \
  -f deploy/linuxone/Containerfile.web \
  -t image-registry.example.com/agrisense/agrisense-web:latest \
  --push .
```

Use a builder running on LinuxONE or a Buildx builder with `linux/s390x`
emulation enabled. Confirm the selected Node image tag and all registry images
publish an `s390x` manifest before deploying.

## Deploy to OpenShift

1. Create or select a namespace and a PostgreSQL service reachable from it.
2. Create a secret; do not put database credentials in the manifest or image:

   ```sh
   oc create secret generic agrisense-db \
     --from-literal=DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require'
   ```

3. Replace the two example image references in `openshift.yaml` with the images
   you built, then apply the resources:

   ```sh
   oc apply -f deploy/linuxone/openshift.yaml
   ```

4. Replace `agrisense.example.com` in `openshift.yaml` with the host for this
   deployment. The included OpenShift Routes send `/` to `agrisense-web` and
   `/api` to `agrisense-api`; the API expects its `/api` prefix to be preserved.
5. Apply the Drizzle schema to the target PostgreSQL database using the
   project's database migration procedure before sending user traffic.

The production deployment needs persistent PostgreSQL storage. Imported
observations and manually entered policy records are stored there; no AGMARKNET
source file is retained after parsing and import.
