import {
  date,
  doublePrecision,
  index,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const marketObservationsTable = pgTable(
  "market_observations",
  {
    id: serial("id").primaryKey(),
    commodity: text("commodity").notNull(),
    sourceCommodity: text("source_commodity").notNull(),
    observedDate: date("observed_date", { mode: "string" }).notNull(),
    state: text("state").notNull(),
    market: text("market").notNull(),
    modalPrice: doublePrecision("modal_price").notNull(),
    minimumPrice: doublePrecision("minimum_price"),
    maximumPrice: doublePrecision("maximum_price"),
    arrivals: doublePrecision("arrivals"),
    unit: text("unit").notNull().default("₹/quintal"),
    variety: text("variety").notNull().default(""),
    grade: text("grade").notNull().default(""),
    sourceFile: text("source_file").notNull().default(""),
    importedAt: timestamp("imported_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("market_observations_natural_key").on(
      table.commodity,
      table.observedDate,
      table.state,
      table.market,
      table.variety,
      table.grade,
    ),
    index("market_observations_crop_state_date").on(
      table.commodity,
      table.state,
      table.observedDate,
    ),
  ],
);

export const insertMarketObservationSchema = createInsertSchema(
  marketObservationsTable,
).omit({ id: true, importedAt: true });
export type InsertMarketObservation = z.infer<
  typeof insertMarketObservationSchema
>;
export type MarketObservationRow = typeof marketObservationsTable.$inferSelect;
export type NewMarketObservationRow = typeof marketObservationsTable.$inferInsert;
