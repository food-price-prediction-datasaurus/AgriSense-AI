import {
  boolean,
  date,
  doublePrecision,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const agriPoliciesTable = pgTable("agri_policies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  policyType: text("policy_type").notNull(),
  commodity: text("commodity"),
  effectiveDate: date("effective_date", { mode: "string" }).notNull(),
  amount: doublePrecision("amount"),
  unit: text("unit"),
  sourceUrl: text("source_url").notNull(),
  verified: boolean("verified").notNull().default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertAgriPolicySchema = createInsertSchema(agriPoliciesTable).omit(
  { id: true, createdAt: true },
);
export type InsertAgriPolicy = z.infer<typeof insertAgriPolicySchema>;
export type AgriPolicyRow = typeof agriPoliciesTable.$inferSelect;
export type NewAgriPolicyRow = typeof agriPoliciesTable.$inferInsert;
