export default function PilotInvitation() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <div className="absolute right-0 top-0 h-full w-[37vw] bg-accent/60" />
      <div className="relative z-10 flex h-full max-w-[80vw] flex-col justify-between">
        <div className="h-[1.2vh] w-[9vw] bg-primary" />
        <div className="max-w-[68vw]">
          <h2 className="font-display text-[6vw] font-extrabold leading-[1] tracking-[-0.05em] text-primary">
            Pilot invitation
          </h2>
          <p className="mt-[4vh] max-w-[60vw] font-display text-[3vw] font-semibold leading-[1.2]">
            Bring representative market data and a real decision workflow.
            We’ll validate signal quality before scaling.
          </p>
        </div>
        <ul className="flex max-w-[64vw] flex-col gap-[2.2vh]">
          <li className="border-t border-primary/25 pt-[1.8vh] font-body text-[2.1vw] leading-[1.3]">
            Seeking a data partner and pilot users.
          </li>
          <li className="border-t border-primary/25 pt-[1.8vh] font-body text-[2.1vw] leading-[1.3]">
            First proof points: data coverage, benchmarked forecast error, and
            workflow fit.
          </li>
        </ul>
      </div>
      <div className="absolute bottom-0 right-0 h-[1.4vh] w-[37vw] bg-primary" />
    </div>
  );
}
