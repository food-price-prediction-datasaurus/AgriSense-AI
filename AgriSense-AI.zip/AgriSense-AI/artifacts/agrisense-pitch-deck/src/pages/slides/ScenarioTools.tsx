export default function ScenarioTools() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <h2 className="font-display text-[4.4vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        Scenario tools
      </h2>
      <div className="mt-[6vh] grid grid-cols-12 gap-[3vw]">
        <div className="col-span-4 flex flex-col justify-between bg-accent/65 px-[2.4vw] py-[3vh]">
          <div className="space-y-[1.5vh]">
            <div className="border-b border-primary/25 pb-[1.5vh] font-display text-[2.15vw] font-bold text-primary">
              raw price
            </div>
            <div className="border-b border-primary/25 pb-[1.5vh] font-display text-[2.15vw] font-bold text-primary">
              yield
            </div>
            <div className="border-b border-primary/25 pb-[1.5vh] font-display text-[2.15vw] font-bold text-primary">
              output price
            </div>
            <div className="font-display text-[2.15vw] font-bold text-primary">
              costs
            </div>
          </div>
          <div className="mt-[3vh] h-[0.8vh] w-[8vw] bg-primary" />
        </div>
        <ul className="col-span-8 flex flex-col gap-[2.2vh] pt-[1vh]">
          <li className="border-b border-primary/15 pb-[1.8vh] font-body text-[2vw] leading-[1.3]">
            Test raw price, yield, output price, and costs in a hypothetical
            processing scenario.
          </li>
          <li className="border-b border-primary/15 pb-[1.8vh] font-body text-[2vw] leading-[1.3]">
            Results are gross-margin scenarios, not observed profitability or
            net profit.
          </li>
          <li className="border-b border-primary/15 pb-[1.8vh] font-body text-[2vw] leading-[1.3]">
            Store sourced MSP and policy records with effective dates and manual
            verification.
          </li>
          <li className="font-body text-[2vw] leading-[1.3]">
            Ask the built-in assistant about price, forecast, risk, seasonality,
            and data coverage in English, Hindi, or Kannada.
          </li>
        </ul>
      </div>
    </div>
  );
}
