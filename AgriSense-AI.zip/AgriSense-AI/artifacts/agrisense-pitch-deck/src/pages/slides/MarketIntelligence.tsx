export default function MarketIntelligence() {
  return (
    <div className="field-grid relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <h2 className="font-display text-[4.4vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        Market intelligence
      </h2>
      <div className="mt-[7vh] grid grid-cols-2 gap-x-[4vw] gap-y-[4vh]">
        <div className="border-t-[0.8vh] border-primary bg-bg/90 px-[2vw] py-[2.2vh]">
          <p className="font-body text-[2.05vw] leading-[1.3]">
            <strong className="font-display font-extrabold text-primary">
              Forecast:
            </strong>{" "}
            7- or 14-day outlook, compared with a 14-day moving-average
            baseline.
          </p>
        </div>
        <div className="border-t-[0.8vh] border-accent bg-bg/90 px-[2vw] py-[2.2vh]">
          <p className="font-body text-[2.05vw] leading-[1.3]">
            <strong className="font-display font-extrabold text-primary">
              Seasonality:
            </strong>{" "}
            monthly and Kharif/Rabi/Zaid price patterns.
          </p>
        </div>
        <div className="border-t-[0.8vh] border-accent bg-bg/90 px-[2vw] py-[2.2vh]">
          <p className="font-body text-[2.05vw] leading-[1.3]">
            <strong className="font-display font-extrabold text-primary">
              Risk and crop comparison:
            </strong>{" "}
            recent movement, volatility, arrivals, and data coverage.
          </p>
        </div>
        <div className="border-t-[0.8vh] border-primary bg-primary px-[2vw] py-[2.2vh] text-bg">
          <p className="font-body text-[2.05vw] leading-[1.3]">
            Results use imported observations—or clearly marked illustrative
            preview data.
          </p>
        </div>
      </div>
    </div>
  );
}
