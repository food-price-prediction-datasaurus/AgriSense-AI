const base = import.meta.env.BASE_URL;

export default function AgriSenseCover() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <div className="absolute inset-y-0 right-0 w-[48vw] overflow-hidden">
        <img
          src={`${base}market-cover.jpg`}
          crossOrigin="anonymous"
          alt="Illustrative wholesale produce market scene, not a specific named mandi."
          className="h-full w-full object-cover"
        />
      </div>
      <div className="relative z-10 flex h-full w-[52vw] flex-col justify-between bg-bg px-[6vw] py-[8vh]">
        <div className="h-[1.2vh] w-[9vw] bg-accent" />
        <div className="max-w-[40vw]">
          <h1 className="font-display text-[6.2vw] font-extrabold leading-[0.98] tracking-[-0.045em] text-primary">
            AgriSense AI
          </h1>
          <p className="mt-[3vh] max-w-[35vw] font-body text-[2.3vw] font-medium leading-[1.28] text-text">
            Evidence-first market intelligence for mandi decisions.
          </p>
        </div>
        <div className="h-[0.5vh] w-[18vw] bg-primary/20" />
      </div>
      <div className="absolute bottom-0 right-0 h-[1.6vh] w-[48vw] bg-accent" />
    </div>
  );
}
