export default function DecisionProblem() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <div className="absolute right-0 top-0 h-full w-[1vw] bg-accent" />
      <h2 className="font-display text-[4.3vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        The decision problem
      </h2>
      <div className="mt-[8vh] grid grid-cols-12 gap-[2vw]">
        <p className="col-span-5 max-w-[40vw] font-display text-[4.2vw] font-bold leading-[1.08] tracking-[-0.04em] text-primary">
          A price quote alone does not tell the whole story.
        </p>
        <ul className="col-span-7 flex flex-col gap-[3.5vh] pt-[1vh]">
          <li className="border-l-[0.45vw] border-accent pl-[1.7vw] font-body text-[2.15vw] leading-[1.35]">
            Decision-makers need the date, mandi, unit, arrival context, and
            source coverage.
          </li>
          <li className="border-l-[0.45vw] border-primary/25 pl-[1.7vw] font-body text-[2.15vw] leading-[1.35]">
            Missing days and mixed units can turn comparisons into misleading
            signals.
          </li>
          <li className="border-l-[0.45vw] border-accent pl-[1.7vw] font-body text-[2.15vw] leading-[1.35]">
            AgriSense starts by checking data readiness before presenting
            analysis.
          </li>
        </ul>
      </div>
    </div>
  );
}
