export default function EvidenceGuardrails() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <div className="absolute inset-y-0 left-0 flex w-[29vw] flex-col justify-center bg-primary px-[5vw]">
        <p className="font-display text-[15vw] font-extrabold leading-none tracking-[-0.08em] text-accent">
          26
        </p>
        <p className="mt-[2vh] max-w-[18vw] font-body text-[2vw] leading-[1.3] text-bg">
          overlapping weekly observations
        </p>
      </div>
      <div className="ml-[29vw] px-[5vw] py-[7vh]">
        <h2 className="font-display text-[4vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
          Evidence and guardrails
        </h2>
        <ul className="mt-[5vh] flex flex-col gap-[2.6vh]">
          <li className="border-b border-primary/15 pb-[2vh] font-body text-[2vw] leading-[1.3]">
            Forecast evaluation compares a fitted linear trend with the baseline
            using chronological holdout MAE.
          </li>
          <li className="border-b border-primary/15 pb-[2vh] font-body text-[2vw] leading-[1.3]">
            Intervals show uncertainty; they are not guaranteed prices.
          </li>
          <li className="border-b border-primary/15 pb-[2vh] font-body text-[2vw] leading-[1.3]">
            Opportunity rankings expose their indicators and are not profit
            estimates.
          </li>
          <li className="font-body text-[2vw] leading-[1.3]">
            Price-transmission analysis requires two real commodity series with
            at least 26 overlapping weekly observations; correlation is not
            causation.
          </li>
        </ul>
      </div>
    </div>
  );
}
