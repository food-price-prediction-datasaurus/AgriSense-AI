export default function DataWorkflow() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <h2 className="font-display text-[4.4vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        A data-first workflow
      </h2>
      <div className="mt-[11vh] grid grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr] items-start gap-[1.2vw]">
        <div className="min-h-[43vh] bg-primary px-[1.7vw] py-[3vh] text-bg">
          <p className="font-display text-[3vw] font-extrabold tracking-[-0.04em] text-accent">
            01
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            Import AGMARKNET CSV observations and map source columns.
          </p>
        </div>
        <p className="pt-[7vh] font-display text-[2.5vw] font-bold text-primary/45">
          →
        </p>
        <div className="min-h-[43vh] bg-primary/8 px-[1.7vw] py-[3vh]">
          <p className="font-display text-[3vw] font-extrabold tracking-[-0.04em] text-primary">
            02
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            Audit date range, commodity/state/market coverage, duplicates, zero
            prices, arrivals, and units.
          </p>
        </div>
        <p className="pt-[7vh] font-display text-[2.5vw] font-bold text-primary/45">
          →
        </p>
        <div className="min-h-[43vh] bg-accent/65 px-[1.7vw] py-[3vh]">
          <p className="font-display text-[3vw] font-extrabold tracking-[-0.04em] text-primary">
            03
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            Preserve source commodity names and reject mixed-unit datasets
            rather than comparing incompatible prices.
          </p>
        </div>
        <p className="pt-[7vh] font-display text-[2.5vw] font-bold text-primary/45">
          →
        </p>
        <div className="min-h-[43vh] bg-primary/8 px-[1.7vw] py-[3vh]">
          <p className="font-display text-[3vw] font-extrabold tracking-[-0.04em] text-primary">
            04
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            Export the observations for review.
          </p>
        </div>
      </div>
    </div>
  );
}
