export default function ValidationRoadmap() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <h2 className="font-display text-[4.4vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        Validation roadmap
      </h2>
      <div className="mt-[10vh] grid grid-cols-4 gap-[2vw]">
        <div className="min-h-[47vh] border-t-[1vh] border-primary bg-primary/5 px-[1.6vw] py-[2.5vh]">
          <p className="font-display text-[2.6vw] font-extrabold text-primary">
            Data:
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            confirm column mapping, units, gaps, and source freshness.
          </p>
        </div>
        <div className="min-h-[47vh] border-t-[1vh] border-accent bg-accent/45 px-[1.6vw] py-[2.5vh]">
          <p className="font-display text-[2.6vw] font-extrabold text-primary">
            Analytics:
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            measure forecast error and coverage on a held-out history.
          </p>
        </div>
        <div className="min-h-[47vh] border-t-[1vh] border-primary bg-primary/5 px-[1.6vw] py-[2.5vh]">
          <p className="font-display text-[2.6vw] font-extrabold text-primary">
            Workflow:
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            test whether users can move from audit to comparison and scenario
            analysis.
          </p>
        </div>
        <div className="min-h-[47vh] border-t-[1vh] border-accent bg-accent/45 px-[1.6vw] py-[2.5vh]">
          <p className="font-display text-[2.6vw] font-extrabold text-primary">
            Commercial:
          </p>
          <p className="mt-[3vh] font-body text-[2vw] leading-[1.35]">
            agree the buyer, value metric, and pricing only after pilot
            feedback.
          </p>
        </div>
      </div>
    </div>
  );
}
