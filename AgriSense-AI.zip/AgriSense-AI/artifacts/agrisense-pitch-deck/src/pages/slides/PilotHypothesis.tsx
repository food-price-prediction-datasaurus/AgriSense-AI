export default function PilotHypothesis() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <div className="absolute bottom-0 left-0 h-[1.3vh] w-full bg-accent" />
      <h2 className="font-display text-[4.4vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        Pilot hypothesis
      </h2>
      <div className="mt-[6vh] grid grid-cols-12 gap-[2vw]">
        <div className="col-span-5 flex min-h-[60vh] flex-col justify-between bg-primary px-[3vw] py-[4vh] text-bg">
          <p className="font-display text-[3vw] font-extrabold leading-[1.15] tracking-[-0.035em]">
            Begin with one selected commodity, state, and mandi workflow.
          </p>
          <div className="h-[1vh] w-[12vw] bg-accent" />
        </div>
        <ul className="col-span-7 flex flex-col justify-between gap-[2vh] py-[1vh]">
          <li className="border-b border-primary/15 pb-[2vh] font-body text-[2.05vw] leading-[1.3]">
            Use a representative official AGMARKNET extract to test ingestion
            and coverage.
          </li>
          <li className="border-b border-primary/15 pb-[2vh] font-body text-[2.05vw] leading-[1.3]">
            Validate the forecast against the moving-average baseline before
            making accuracy claims.
          </li>
          <li className="font-body text-[2.05vw] leading-[1.3]">
            Identify the intended buyer, usage cadence, and commercial model
            through pilot discovery.
          </li>
        </ul>
      </div>
    </div>
  );
}
