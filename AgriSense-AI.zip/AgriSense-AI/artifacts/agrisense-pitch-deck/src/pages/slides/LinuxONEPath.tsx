export default function LinuxONEPath() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg px-[6vw] py-[7vh] text-text">
      <h2 className="font-display text-[4.3vw] font-extrabold leading-tight tracking-[-0.04em] text-primary">
        IBM LinuxONE deployment path
      </h2>
      <div className="mt-[8vh] flex items-center justify-between bg-primary px-[3vw] py-[4vh] text-bg">
        <p className="max-w-[24vw] font-display text-[2.1vw] font-bold leading-[1.3]">
          React/Vite web app → Node.js API → PostgreSQL with Drizzle.
        </p>
        <svg
          aria-hidden="true"
          viewBox="0 0 180 80"
          className="h-[8vh] w-[12vw] text-accent"
          fill="none"
        >
          <path d="M8 40h150m0 0-26-25m26 25-26 25" stroke="currentColor" strokeWidth="5" />
        </svg>
        <p className="max-w-[19vw] font-display text-[2.4vw] font-extrabold leading-[1.2] text-accent">
          linux/s390x
        </p>
      </div>
      <div className="mt-[6vh] grid grid-cols-3 gap-[3vw]">
        <p className="border-t-[0.7vh] border-accent pt-[2vh] font-body text-[2vw] leading-[1.32]">
          OCI container build files target linux/s390x.
        </p>
        <p className="border-t-[0.7vh] border-primary/30 pt-[2vh] font-body text-[2vw] leading-[1.32]">
          OpenShift manifests define web/API services and routed paths.
        </p>
        <p className="border-t-[0.7vh] border-accent pt-[2vh] font-body text-[2vw] leading-[1.32]">
          Prepared for IBM LinuxONE deployment; not yet deployed to an IBM
          cluster.
        </p>
      </div>
    </div>
  );
}
