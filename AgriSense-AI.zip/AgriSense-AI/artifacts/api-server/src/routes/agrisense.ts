import { Router, type IRouter } from "express";
import { desc, eq, sql } from "drizzle-orm";
import {
  agriPoliciesTable,
  db,
  marketObservationsTable,
} from "@workspace/db";
import {
  AskAgriAssistantBody,
  AskAgriAssistantResponse,
  CalculateAgriScenarioBody,
  CalculateAgriScenarioResponse,
  CreateAgriPolicyBody,
  CreateAgriPolicyResponse,
  DeleteAgriPolicyParams,
  GetAgriAuditResponse,
  GetAgriCatalogueResponse,
  GetAgriDashboardResponse,
  GetAgriForecastQueryParams,
  GetAgriForecastResponse,
  GetAgriObservationsQueryParams,
  GetAgriObservationsResponse,
  GetAgriOpportunityQueryParams,
  GetAgriOpportunityResponse,
  GetAgriPoliciesResponse,
  GetAgriRiskQueryParams,
  GetAgriRiskResponse,
  GetAgriSeasonalityQueryParams,
  GetAgriSeasonalityResponse,
  GetAgriTransmissionQueryParams,
  GetAgriTransmissionResponse,
  ImportAgriObservationsBody,
  ImportAgriObservationsResponse,
} from "@workspace/api-zod";
import {
  assistantAnswer,
  buildAudit,
  buildCatalogue,
  buildDashboard,
  buildForecast,
  buildOpportunity,
  buildRisk,
  buildSeasonality,
  buildTransmission,
  calculateScenario,
  filterObservations,
  fromDatabaseRow,
  getIllustrativeObservations,
} from "../lib/agri-analytics";

const router: IRouter = Router();
const MAX_ANALYSIS_ROWS = 250_000;
const INSERT_BATCH_SIZE = 500;

async function loadObservations() {
  const stored = await db
    .select()
    .from(marketObservationsTable)
    .orderBy(desc(marketObservationsTable.observedDate))
    .limit(MAX_ANALYSIS_ROWS);
  return stored.length
    ? stored.map(fromDatabaseRow)
    : getIllustrativeObservations();
}

function normalizeUnit(unit: string): string {
  const value = unit.trim().replace(/\s+/g, " ");
  const lower = value.toLowerCase();
  if (lower.includes("quintal") || /\bqtl\b/.test(lower)) return "₹/quintal";
  if (/\bkg\b|kilogram/.test(lower)) return "₹/kg";
  if (/tonne|metric ton|metric tonne/.test(lower)) return "₹/tonne";
  return value.replace(/^inr\b/i, "₹").replace(/^rs\.?\b/i, "₹");
}

function normalizedText(value: string): string {
  return value.trim().replace(/\s+/g, " ");
}

router.get("/agri/dashboard", async (_req, res): Promise<void> => {
  const result = GetAgriDashboardResponse.parse(
    buildDashboard(await loadObservations()),
  );
  res.json(result);
});

router.get("/agri/catalogue", async (_req, res): Promise<void> => {
  const result = GetAgriCatalogueResponse.parse(
    buildCatalogue(await loadObservations()),
  );
  res.json(result);
});

router.get("/agri/audit", async (_req, res): Promise<void> => {
  const result = GetAgriAuditResponse.parse(
    buildAudit(await loadObservations()),
  );
  res.json(result);
});

router.get("/agri/observations", async (req, res): Promise<void> => {
  const parsed = GetAgriObservationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.flatten() }, "Invalid observation filters");
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const rows = filterObservations(await loadObservations(), {
    ...parsed.data,
    from: parsed.data.from?.toISOString().slice(0, 10),
    to: parsed.data.to?.toISOString().slice(0, 10),
  })
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, parsed.data.limit);
  res.json(GetAgriObservationsResponse.parse(rows));
});

router.post("/agri/import", async (req, res): Promise<void> => {
  const parsed = ImportAgriObservationsBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.flatten() }, "Invalid market data import");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const incomingUnits = [
    ...new Set(parsed.data.rows.map((row) => normalizeUnit(row.unit))),
  ];
  if (incomingUnits.length !== 1) {
    res.status(400).json({
      error: "One import must use one consistent price unit. Convert mixed units before importing.",
    });
    return;
  }
  const existingUnits = await db
    .selectDistinct({ unit: marketObservationsTable.unit })
    .from(marketObservationsTable);
  if (
    existingUnits.some(
      (entry) => entry.unit !== incomingUnits[0],
    )
  ) {
    res.status(409).json({
      error: `The dataset already uses ${existingUnits
        .map((entry) => entry.unit)
        .join(", ")}. Convert the new file to the existing unit before importing.`,
    });
    return;
  }

  const distinct = new Map<
    string,
    (typeof parsed.data.rows)[number]
  >();
  parsed.data.rows.forEach((row) => {
    const canonicalRow = {
      ...row,
      commodity: normalizedText(row.commodity),
      sourceCommodity: normalizedText(row.sourceCommodity),
      state: normalizedText(row.state),
      market: normalizedText(row.market),
      unit: incomingUnits[0]!,
      variety: row.variety ? normalizedText(row.variety) : null,
      grade: row.grade ? normalizedText(row.grade) : null,
    };
    const key = [
      canonicalRow.commodity.toLocaleLowerCase(),
      canonicalRow.date,
      canonicalRow.state.toLocaleLowerCase(),
      canonicalRow.market.toLocaleLowerCase(),
      canonicalRow.variety?.toLocaleLowerCase() ?? "",
      canonicalRow.grade?.toLocaleLowerCase() ?? "",
    ].join("\u0000");
    distinct.set(key, canonicalRow);
  });
  const rows = [...distinct.values()].filter(
    (row) =>
      row.minimumPrice == null ||
      row.maximumPrice == null ||
      row.minimumPrice <= row.maximumPrice,
  );
  const rejected =
    parsed.data.rows.length - rows.length;
  if (!rows.length) {
    res.status(400).json({ error: "No usable rows remain after duplicate and price-range checks." });
    return;
  }

  const sourceFile = normalizedText(parsed.data.fileName).slice(0, 255);
  const values = rows.map((row) => ({
    commodity: row.commodity,
    sourceCommodity: row.sourceCommodity,
      observedDate: row.date.toISOString().slice(0, 10),
    state: row.state,
    market: row.market,
    modalPrice: row.modalPrice,
    minimumPrice: row.minimumPrice ?? null,
    maximumPrice: row.maximumPrice ?? null,
    arrivals: row.arrivals ?? null,
    unit: row.unit,
    variety: row.variety ?? "",
    grade: row.grade ?? "",
    sourceFile,
  }));
  for (let start = 0; start < values.length; start += INSERT_BATCH_SIZE) {
    const batch = values.slice(start, start + INSERT_BATCH_SIZE);
    await db
      .insert(marketObservationsTable)
      .values(batch)
      .onConflictDoUpdate({
        target: [
          marketObservationsTable.commodity,
          marketObservationsTable.observedDate,
          marketObservationsTable.state,
          marketObservationsTable.market,
          marketObservationsTable.variety,
          marketObservationsTable.grade,
        ],
        set: {
          sourceCommodity: sql`excluded.source_commodity`,
          modalPrice: sql`excluded.modal_price`,
          minimumPrice: sql`excluded.minimum_price`,
          maximumPrice: sql`excluded.maximum_price`,
          arrivals: sql`excluded.arrivals`,
          unit: sql`excluded.unit`,
          sourceFile: sql`excluded.source_file`,
          importedAt: sql`now()`,
        },
      });
  }
  const result = ImportAgriObservationsResponse.parse({
    imported: rows.length,
    rejected,
    audit: buildAudit(await loadObservations()),
  });
  req.log.info(
    { fileName: sourceFile, imported: rows.length, rejected },
    "Market data import completed",
  );
  res.json(result);
});

router.get("/agri/forecast", async (req, res): Promise<void> => {
  const parsed = GetAgriForecastQueryParams.safeParse({
    ...req.query,
    horizon:
      req.query.horizon === undefined ? undefined : Number(req.query.horizon),
  });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const report = buildForecast(await loadObservations(), parsed.data);
  if (!report) {
    res.status(404).json({
      error: "At least 10 matching daily observations are needed to produce a forecast.",
    });
    return;
  }
  res.json(GetAgriForecastResponse.parse(report));
});

router.get("/agri/seasonality", async (req, res): Promise<void> => {
  const parsed = GetAgriSeasonalityQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(
    GetAgriSeasonalityResponse.parse(
      buildSeasonality(await loadObservations(), parsed.data),
    ),
  );
});

router.get("/agri/risk", async (req, res): Promise<void> => {
  const parsed = GetAgriRiskQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(
    GetAgriRiskResponse.parse(
      buildRisk(await loadObservations(), parsed.data),
    ),
  );
});

router.get("/agri/opportunity", async (req, res): Promise<void> => {
  const parsed = GetAgriOpportunityQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(
    GetAgriOpportunityResponse.parse(
      buildOpportunity(await loadObservations(), parsed.data),
    ),
  );
});

router.get("/agri/transmission", async (req, res): Promise<void> => {
  const parsed = GetAgriTransmissionQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(
    GetAgriTransmissionResponse.parse(
      buildTransmission(await loadObservations(), parsed.data),
    ),
  );
});

router.post("/agri/scenario", async (req, res): Promise<void> => {
  const parsed = CalculateAgriScenarioBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(CalculateAgriScenarioResponse.parse(calculateScenario(parsed.data)));
});

router.get("/agri/policies", async (_req, res): Promise<void> => {
  const policies = await db
    .select()
    .from(agriPoliciesTable)
    .orderBy(desc(agriPoliciesTable.effectiveDate));
  const result = policies.map((policy) => ({
    ...policy,
    createdAt: policy.createdAt.toISOString(),
  }));
  res.json(GetAgriPoliciesResponse.parse(result));
});

router.post("/agri/policies", async (req, res): Promise<void> => {
  const parsed = CreateAgriPolicyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  let source: URL;
  try {
    source = new URL(parsed.data.sourceUrl);
  } catch {
    res.status(400).json({ error: "Source URL must be an absolute HTTP or HTTPS URL." });
    return;
  }
  if (source.protocol !== "http:" && source.protocol !== "https:") {
    res.status(400).json({ error: "Source URL must use HTTP or HTTPS." });
    return;
  }
  const [policy] = await db
    .insert(agriPoliciesTable)
    .values({
      title: normalizedText(parsed.data.title),
      policyType: parsed.data.policyType,
      commodity: parsed.data.commodity ?? null,
      effectiveDate: parsed.data.effectiveDate.toISOString().slice(0, 10),
      amount: parsed.data.amount ?? null,
      unit: parsed.data.unit ?? null,
      sourceUrl: parsed.data.sourceUrl,
      verified: parsed.data.verified,
      notes: parsed.data.notes ?? null,
    })
    .returning();
  if (!policy) {
    res.status(500).json({ error: "Policy record could not be saved." });
    return;
  }
  res
    .status(201)
    .json(
      CreateAgriPolicyResponse.parse({
        ...policy,
        createdAt: policy.createdAt.toISOString(),
      }),
    );
});

router.delete("/agri/policies/:id", async (req, res): Promise<void> => {
  const parsed = DeleteAgriPolicyParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [deleted] = await db
    .delete(agriPoliciesTable)
    .where(eq(agriPoliciesTable.id, parsed.data.id))
    .returning({ id: agriPoliciesTable.id });
  if (!deleted) {
    res.status(404).json({ error: "Policy record not found." });
    return;
  }
  res.sendStatus(204);
});

router.post("/agri/chat", async (req, res): Promise<void> => {
  const parsed = AskAgriAssistantBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.json(
    AskAgriAssistantResponse.parse(
      assistantAnswer(
        parsed.data.question,
        parsed.data.language,
        await loadObservations(),
        parsed.data.commodity,
        parsed.data.state,
      ),
    ),
  );
});

export default router;
