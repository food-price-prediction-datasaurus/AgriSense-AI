import { Router, type IRouter } from "express";
import healthRouter from "./health";
import agrisenseRouter from "./agrisense";

const router: IRouter = Router();

router.use(healthRouter);
router.use(agrisenseRouter);

export default router;
