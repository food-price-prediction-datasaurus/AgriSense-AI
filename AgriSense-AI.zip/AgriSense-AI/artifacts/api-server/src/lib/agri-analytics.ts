export type DataSource = "imported" | "illustrative";

export interface Observation {
  id: string;
  commodity: string;
  sourceCommodity: string;
  date: string;
  state: string;
  market: string;
  modalPrice: number;
  minimumPrice: number | null;
  maximumPrice: number | null;
  arrivals: number | null;
  unit: string;
  variety: string | null;
  grade: string | null;
  dataSource: DataSource;
}

type Product = {
  name: string;
  category: string;
  base: number;
  annualTrend: number;
  sourceNames: string[];
};

const PRODUCTS: Product[] = [
  { name: "Soyabean", category: "Oilseed", base: 4700, annualTrend: 0.045, sourceNames: ["Soyabean", "Soybean"] },
  { name: "Groundnut", category: "Oilseed", base: 6400, annualTrend: 0.035, sourceNames: ["Groundnut", "Peanut"] },
  { name: "Mustard", category: "Oilseed", base: 5400, annualTrend: 0.04, sourceNames: ["Mustard", "Rai"] },
  { name: "Kapas", category: "Fibre", base: 7200, annualTrend: 0.03, sourceNames: ["Kapas", "Cotton"] },
  { name: "Maize", category: "Cereal", base: 2200, annualTrend: 0.025, sourceNames: ["Maize", "Corn"] },
  { name: "Turmeric", category: "Spice", base: 12000, annualTrend: 0.055, sourceNames: ["Turmeric"] },
  { name: "Tomato", category: "Vegetable", base: 2500, annualTrend: 0.02, sourceNames: ["Tomato"] },
  { name: "Onion", category: "Vegetable", base: 2300, annualTrend: 0.025, sourceNames: ["Onion"] },
  { name: "Wheat", category: "Cereal", base: 2600, annualTrend: 0.03, sourceNames: ["Wheat"] },
];

const MARKETS = [
  { state: "Maharashtra", market: "Akola" },
  { state: "Maharashtra", market: "Latur" },
  { state: "Karnataka", market: "Davanagere" },
  { state: "Karnataka", market: "Hubballi" },
];

const SEASONS = [
  { name: "Kharif", months: [6, 7, 8, 9, 10] },
  { name: "Rabi", months: [11, 12, 1, 2, 3] },
  { name: "Zaid", months: [4, 5] },
];

const dayMs = 86_400_000;

function isoDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function makeIllustrativeObservations(): Observation[] {
  const end = new Date();
  end.setUTCHours(0, 0, 0, 0);
  const start = new Date(end.getTime() - 3 * 365 * dayMs);
  const observations: Observation[] = [];
  let day = 0;

  for (
    let time = start.getTime();
    time <= end.getTime();
    time += dayMs, day += 1
  ) {
    const date = new Date(time);
    const month = date.getUTCMonth();
    const annualSeason = Math.sin(((month - 1) / 12) * Math.PI * 2);
    PRODUCTS.forEach((product, productIndex) => {
      MARKETS.forEach((market, marketIndex) => {
        const trend = 1 + product.annualTrend * (day / 365);
        const seasonal = 1 + 0.075 * annualSeason;
        const shortCycle =
          1 +
          0.016 *
            Math.sin(day * 0.31 + productIndex * 2.1 + marketIndex * 0.7);
        const marketFactor = 0.975 + marketIndex * 0.014;
        const modalPrice = Math.round(
          product.base * trend * seasonal * shortCycle * marketFactor,
        );
        const arrivals = Math.max(
          1,
          Math.round(
            65 +
              20 * Math.sin(day * 0.037 + productIndex) +
              marketIndex * 7,
          ),
        );
        observations.push({
          id: `illustrative-${productIndex}-${marketIndex}-${isoDate(date)}`,
          commodity: product.name,
          sourceCommodity: product.sourceNames[0],
          date: isoDate(date),
          state: market.state,
          market: market.market,
          modalPrice,
          minimumPrice: Math.round(modalPrice * 0.97),
          maximumPrice: Math.round(modalPrice * 1.03),
          arrivals,
          unit: "₹/quintal",
          variety: null,
          grade: null,
          dataSource: "illustrative",
        });
      });
    });
  }
  return observations;
}

const illustrativeData = makeIllustrativeObservations();

export function getIllustrativeObservations(): Observation[] {
  return illustrativeData;
}

export function fromDatabaseRow(row: {
  id: number;
  commodity: string;
  sourceCommodity: string;
  observedDate: string;
  state: string;
  market: string;
  modalPrice: number;
  minimumPrice: number | null;
  maximumPrice: number | null;
  arrivals: number | null;
  unit: string;
  variety: string;
  grade: string;
}): Observation {
  return {
    id: String(row.id),
    commodity: row.commodity,
    sourceCommodity: row.sourceCommodity,
    date: row.observedDate,
    state: row.state,
    market: row.market,
    modalPrice: row.modalPrice,
    minimumPrice: row.minimumPrice,
    maximumPrice: row.maximumPrice,
    arrivals: row.arrivals,
    unit: row.unit,
    variety: row.variety || null,
    grade: row.grade || null,
    dataSource: "imported",
  };
}

export function filterObservations(
  rows: Observation[],
  filter: {
    commodity?: string;
    state?: string;
    market?: string;
    from?: string;
    to?: string;
  },
): Observation[] {
  return rows.filter(
    (row) =>
      (!filter.commodity || row.commodity === filter.commodity) &&
      (!filter.state || row.state === filter.state) &&
      (!filter.market || row.market === filter.market) &&
      (!filter.from || row.date >= filter.from) &&
      (!filter.to || row.date <= filter.to),
  );
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function mean(values: number[]): number {
  if (!values.length) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function standardDeviation(values: number[]): number {
  if (values.length < 2) return 0;
  const average = mean(values);
  return Math.sqrt(
    values.reduce((sum, value) => sum + (value - average) ** 2, 0) /
      (values.length - 1),
  );
}

function uniqueSorted(values: string[]): string[] {
  return [...new Set(values)].sort((a, b) => a.localeCompare(b));
}

type DayPoint = { date: string; price: number; arrivals: number | null };

function groupByDay(rows: Observation[]): DayPoint[] {
  const grouped = new Map<string, Observation[]>();
  rows.forEach((row) => {
    const existing = grouped.get(row.date) ?? [];
    existing.push(row);
    grouped.set(row.date, existing);
  });
  return [...grouped.entries()]
    .map(([date, dayRows]) => ({
      date,
      price: mean(dayRows.map((row) => row.modalPrice)),
      arrivals: dayRows.some((row) => row.arrivals !== null)
        ? mean(dayRows.flatMap((row) => (row.arrivals === null ? [] : [row.arrivals])))
        : null,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

function getCoverageScore(rows: Observation[]): number {
  if (rows.length < 2) return rows.length ? 1 : 0;
  const days = groupByDay(rows);
  const spanDays =
    (new Date(days[days.length - 1]!.date).getTime() -
      new Date(days[0]!.date).getTime()) /
      dayMs +
    1;
  if (spanDays <= 0) return 0;
  return Math.round(clamp((days.length / spanDays) * 100, 0, 100));
}

function percentChange(current: number, prior: number): number {
  if (!prior) return 0;
  return ((current - prior) / prior) * 100;
}

function regression(points: number[]): { intercept: number; slope: number } {
  if (!points.length) return { intercept: 0, slope: 0 };
  const xMean = (points.length - 1) / 2;
  const yMean = mean(points);
  let numerator = 0;
  let denominator = 0;
  points.forEach((y, index) => {
    numerator += (index - xMean) * (y - yMean);
    denominator += (index - xMean) ** 2;
  });
  const slope = denominator ? numerator / denominator : 0;
  return { intercept: yMean - slope * xMean, slope };
}

function trendForecast(days: DayPoint[], horizon: number): number {
  const recent = days.slice(-60);
  const fit = regression(recent.map((point) => point.price));
  return fit.intercept + fit.slope * (recent.length - 1 + horizon);
}

function getRecentChange(days: DayPoint[]): number {
  if (days.length < 2) return 0;
  const recent = days.slice(-7).map((point) => point.price);
  const prior = days.slice(-14, -7).map((point) => point.price);
  return percentChange(mean(recent), mean(prior.length ? prior : days.slice(0, 1).map((point) => point.price)));
}

export function buildAudit(rows: Observation[]) {
  const illustrative = rows.some((row) => row.dataSource === "illustrative");
  const commodities = uniqueSorted(rows.map((row) => row.commodity));
  const coverage = commodities.map((commodity) => {
    const cropRows = rows.filter((row) => row.commodity === commodity);
    const dates = uniqueSorted(cropRows.map((row) => row.date));
    const firstDate = dates[0] ?? null;
    const lastDate = dates[dates.length - 1] ?? null;
    const spanDays =
      firstDate && lastDate
        ? (new Date(lastDate).getTime() - new Date(firstDate).getTime()) /
            dayMs +
          1
        : 0;
    const states = uniqueSorted(cropRows.map((row) => row.state));
    const years = spanDays / 365;
    return {
      commodity,
      states,
      markets: new Set(cropRows.map((row) => `${row.state}/${row.market}`)).size,
      firstDate,
      lastDate,
      recordCount: cropRows.length,
      daysWithDataPercent: spanDays
        ? Math.round(clamp((dates.length / spanDays) * 100, 0, 100) * 10) / 10
        : 0,
      arrivalsCoverage: cropRows.length
        ? Math.round(
            (cropRows.filter((row) => row.arrivals !== null).length /
              cropRows.length) *
              1000,
          ) / 10
        : 0,
      status: illustrative
        ? ("illustrative" as const)
        : years >= 3 && states.length >= 2
          ? ("live" as const)
          : ("needs-more-history" as const),
    };
  });
  const dates = uniqueSorted(rows.map((row) => row.date));
  return {
    isIllustrative: illustrative,
    recordCount: rows.length,
    commodityCount: commodities.length,
    stateCount: new Set(rows.map((row) => row.state)).size,
    marketCount: new Set(rows.map((row) => `${row.state}/${row.market}`)).size,
    firstDate: dates[0] ?? null,
    lastDate: dates[dates.length - 1] ?? null,
    priceUnit: uniqueSorted(rows.map((row) => row.unit)).join(", ") || "Not set",
    arrivalsCoverage: rows.length
      ? Math.round(
          (rows.filter((row) => row.arrivals !== null).length / rows.length) *
            1000,
        ) / 10
      : 0,
    duplicateCount: 0,
    zeroPriceCount: rows.filter((row) => row.modalPrice <= 0).length,
    coverage,
  };
}

export function buildCatalogue(rows: Observation[]) {
  const audit = buildAudit(rows);
  const known = PRODUCTS.map((product) => {
    const cell = audit.coverage.find((item) => item.commodity === product.name);
    const status = !cell
      ? audit.isIllustrative
        ? "illustrative"
        : "needs-import"
      : cell.status === "live"
        ? "live"
        : cell.status === "illustrative"
          ? "illustrative"
          : "needs-import";
    return {
      commodity: product.name,
      category: product.category,
      sourceNames: product.sourceNames,
      rawStageStatus: status,
      processingStatus: "scenario-only" as const,
      dataStatus: status,
    };
  });
  const dynamic = audit.coverage
    .filter((cell) => !PRODUCTS.some((product) => product.name === cell.commodity))
    .map((cell) => ({
      commodity: cell.commodity,
      category: "Other",
      sourceNames: [cell.commodity],
      rawStageStatus: cell.status === "live" ? "live" as const : "needs-import" as const,
      processingStatus: "scenario-only" as const,
      dataStatus: cell.status === "live" ? "live" as const : "needs-import" as const,
    }));
  return [...known, ...dynamic];
}

export function buildDashboard(rows: Observation[]) {
  const sorted = [...rows].sort((a, b) => b.date.localeCompare(a.date));
  const illustrative = rows.some((row) => row.dataSource === "illustrative");
  return {
    audit: buildAudit(rows),
    latestObservations: sorted.slice(0, 8),
    commodityOptions: uniqueSorted(rows.map((row) => row.commodity)),
    stateOptions: uniqueSorted(rows.map((row) => row.state)),
    marketOptions: uniqueSorted(rows.map((row) => row.market)),
    dataNotice: illustrative
      ? "Illustrative synthetic preview only — not official AGMARKNET observations. Import your AGMARKNET file to replace this preview."
      : "Using imported market observations. Coverage and units reflect the contents of your file; review the audit before relying on an analysis.",
  };
}

export function buildForecast(
  rows: Observation[],
  query: { commodity: string; state: string; market?: string; horizon: number },
) {
  const matches = filterObservations(rows, query);
  const days = groupByDay(matches);
  if (days.length < 10) return null;
  const horizon = query.horizon;
  const chartDays = days.slice(-90);
  const history = chartDays.map((point, index) => {
    const prior = chartDays.slice(Math.max(0, index - 13), index + 1);
    const fit = regression(chartDays.slice(Math.max(0, index - 59), index + 1).map((entry) => entry.price));
    const model = fit.intercept + fit.slope * (Math.min(index, 59));
    const residual = standardDeviation(prior.map((entry) => entry.price));
    return {
      date: point.date,
      observed: point.price,
      baseline: mean(prior.map((entry) => entry.price)),
      model,
      lower: Math.max(0, model - residual),
      upper: model + residual,
    };
  });
  const holdoutStart = Math.max(14, days.length - 28);
  const baselineErrors: number[] = [];
  const modelErrors: number[] = [];
  for (let index = holdoutStart; index < days.length; index += 1) {
    const training = days.slice(0, index);
    const actual = days[index]!.price;
    const baseline = mean(training.slice(-14).map((point) => point.price));
    const recent = training.slice(-60).map((point) => point.price);
    const fit = regression(recent);
    const prediction = fit.intercept + fit.slope * recent.length;
    baselineErrors.push(Math.abs(actual - baseline));
    modelErrors.push(Math.abs(actual - prediction));
  }
  const last = days[days.length - 1]!;
  const baselinePrice = mean(days.slice(-14).map((point) => point.price));
  const trendFit = regression(days.slice(-60).map((point) => point.price));
  const recentResiduals = days
    .slice(-60)
    .map((point, index, source) => point.price - source[0]!.price);
  const intervalUnit = Math.max(
    standardDeviation(recentResiduals) * Math.sqrt(horizon / 7) * 0.25,
    last.price * 0.015,
  );
  const future: Array<{
    date: string;
    observed: null;
    baseline: number;
    model: number;
    lower: number;
    upper: number;
  }> = [];
  const lastDate = new Date(`${last.date}T00:00:00.000Z`);
  for (let step = 1; step <= horizon; step += 1) {
    const model = Math.max(
      0,
      trendFit.intercept + trendFit.slope * (Math.min(days.slice(-60).length - 1, 59) + step),
    );
    const spread = intervalUnit * Math.sqrt(step / 7);
    const date = new Date(lastDate.getTime() + step * dayMs);
    future.push({
      date: isoDate(date),
      observed: null,
      baseline: baselinePrice,
      model,
      lower: Math.max(0, model - spread),
      upper: model + spread,
    });
  }
  return {
    commodity: query.commodity,
    state: query.state,
    market: query.market || "All markets",
    horizon,
    unit: matches[matches.length - 1]!.unit,
    historical: history,
    forecast: future,
    baselineMae: baselineErrors.length ? mean(baselineErrors) : null,
    modelMae: modelErrors.length ? mean(modelErrors) : null,
    dataCoverage: getCoverageScore(matches),
    method: "Chronological holdout: 14-day moving-average baseline vs. fitted linear-trend regression.",
    isIllustrative: matches.some((row) => row.dataSource === "illustrative"),
  };
}

export function buildSeasonality(
  rows: Observation[],
  query: { commodity: string; state?: string },
) {
  const matches = filterObservations(rows, query);
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthly = monthNames.map((month, index) => {
    const monthRows = matches.filter(
      (row) => new Date(`${row.date}T00:00:00.000Z`).getUTCMonth() === index,
    );
    return {
      month,
      averagePrice: monthRows.length ? mean(monthRows.map((row) => row.modalPrice)) : null,
      observations: monthRows.length,
    };
  });
  const seasons = SEASONS.map((season) => {
    const seasonRows = matches.filter((row) =>
      season.months.includes(new Date(`${row.date}T00:00:00.000Z`).getUTCMonth() + 1),
    );
    return {
      name: season.name,
      months: season.months,
      averagePrice: seasonRows.length
        ? mean(seasonRows.map((row) => row.modalPrice))
        : null,
      observations: seasonRows.length,
    };
  });
  return {
    commodity: query.commodity,
    state: query.state || null,
    unit: matches[0]?.unit ?? "₹/quintal",
    monthly,
    seasons,
    isIllustrative: matches.some((row) => row.dataSource === "illustrative"),
  };
}

export function buildRisk(
  rows: Observation[],
  query: { state: string; commodity?: string },
) {
  const matches = filterObservations(rows, query);
  const grouped = new Map<string, Observation[]>();
  matches.forEach((row) => {
    const key = `${row.commodity}\u0000${row.market}`;
    const existing = grouped.get(key) ?? [];
    existing.push(row);
    grouped.set(key, existing);
  });
  return [...grouped.values()]
    .map((marketRows) => {
      const days = groupByDay(marketRows);
      const latest = days[days.length - 1]!;
      const previous = getRecentChange(days);
      const recentDays = days.slice(-61);
      const returns = recentDays.slice(1).map((point, index) =>
        percentChange(point.price, recentDays[index]!.price),
      );
      const volatility = standardDeviation(returns);
      const coverage = getCoverageScore(marketRows);
      const forecastPrice = trendForecast(days, 14);
      const riskScore = clamp(
        volatility * 2.1 + Math.abs(previous) * 1.6 + (100 - coverage) * 0.22,
        0,
        100,
      );
      const lastRecord = marketRows
        .filter((row) => row.date === latest.date)
        .at(-1)!;
      return {
        commodity: lastRecord.commodity,
        state: lastRecord.state,
        market: lastRecord.market,
        latestPrice: latest.price,
        recentChangePercent: previous,
        forecastChangePercent: percentChange(forecastPrice, latest.price),
        volatilityPercent: volatility,
        arrivals: latest.arrivals,
        recordCount: marketRows.length,
        coverageScore: coverage,
        riskScore: Math.round(riskScore * 10) / 10,
        unit: lastRecord.unit,
        isIllustrative: marketRows.some((row) => row.dataSource === "illustrative"),
      };
    })
    .sort((a, b) => b.riskScore - a.riskScore);
}

export function buildOpportunity(
  rows: Observation[],
  query: { state: string; objective: "stability" | "price-trend" },
) {
  const stateRows = filterObservations(rows, { state: query.state });
  const commodities = uniqueSorted(stateRows.map((row) => row.commodity));
  return commodities
    .map((commodity) => {
      const cropRows = stateRows.filter((row) => row.commodity === commodity);
      const days = groupByDay(cropRows);
      const latest = days[days.length - 1]!;
      const trend = percentChange(
        mean(days.slice(-14).map((point) => point.price)),
        mean(days.slice(-60, -46).map((point) => point.price)),
      );
      const recentDays = days.slice(-61);
      const returns = recentDays.slice(1).map((point, index) =>
        percentChange(point.price, recentDays[index]!.price),
      );
      const volatility = standardDeviation(returns);
      const monthMeans = Array.from({ length: 12 }, (_, month) => {
        const monthRows = cropRows.filter(
          (row) =>
            new Date(`${row.date}T00:00:00.000Z`).getUTCMonth() === month,
        );
        return monthRows.length
          ? mean(monthRows.map((row) => row.modalPrice))
          : null;
      }).filter((price): price is number => price !== null);
      const seasonalityIndex = monthMeans.length
        ? Math.max(...monthMeans) / Math.max(1, mean(monthMeans))
        : 1;
      const coverage = getCoverageScore(cropRows);
      const arrivalsValues = cropRows.flatMap((row) =>
        row.arrivals === null ? [] : [row.arrivals],
      );
      const arrivals = arrivalsValues.length ? mean(arrivalsValues) : null;
      const trendScore = clamp(50 + trend * 2.2, 0, 100);
      const volatilityScore = clamp(100 - volatility * 2.4, 0, 100);
      const arrivalScore = arrivals === null
        ? 0
        : clamp((arrivals / Math.max(1, ...commodities.map((name) => {
            const values = stateRows
              .filter((row) => row.commodity === name && row.arrivals !== null)
              .map((row) => row.arrivals!);
            return mean(values);
          }))) * 100, 0, 100);
      const score =
        query.objective === "stability"
          ? volatilityScore * 0.55 + coverage * 0.3 + arrivalScore * 0.15
          : trendScore * 0.45 + volatilityScore * 0.2 + coverage * 0.2 + arrivalScore * 0.15;
      const product = PRODUCTS.find((item) => item.name === commodity);
      const indicators = [
        `Recent price trend: ${trend >= 0 ? "+" : ""}${trend.toFixed(1)}%`,
        `Price volatility: ${volatility.toFixed(1)}%`,
        `Data coverage: ${coverage}%`,
        arrivals === null
          ? "Arrivals: not available"
          : `Average arrivals: ${arrivals.toFixed(1)}`,
      ];
      return {
        commodity,
        category: product?.category ?? "Other",
        latestPrice: latest.price,
        trendPercent: trend,
        volatilityPercent: volatility,
        seasonalityIndex,
        arrivals,
        coverageScore: coverage,
        score: Math.round(score * 10) / 10,
        indicators,
        unit: cropRows[cropRows.length - 1]!.unit,
        isIllustrative: cropRows.some((row) => row.dataSource === "illustrative"),
      };
    })
    .sort((a, b) => b.score - a.score);
}

function pearsonCorrelation(left: number[], right: number[]): number | null {
  if (left.length < 3 || left.length !== right.length) return null;
  const leftMean = mean(left);
  const rightMean = mean(right);
  let numerator = 0;
  let leftVariance = 0;
  let rightVariance = 0;
  left.forEach((value, index) => {
    const a = value - leftMean;
    const b = right[index]! - rightMean;
    numerator += a * b;
    leftVariance += a * a;
    rightVariance += b * b;
  });
  const denominator = Math.sqrt(leftVariance * rightVariance);
  return denominator ? numerator / denominator : null;
}

export function buildTransmission(
  rows: Observation[],
  query: { inputCommodity: string; outputCommodity: string; state?: string },
) {
  const selected = rows.filter(
    (row) =>
      (row.commodity === query.inputCommodity ||
        row.commodity === query.outputCommodity) &&
      (!query.state || row.state === query.state),
  );
  const weekly = new Map<
    number,
    { input: number[]; output: number[]; date: string }
  >();
  selected.forEach((row) => {
    const week = Math.floor(new Date(`${row.date}T00:00:00.000Z`).getTime() / dayMs / 7);
    const entry = weekly.get(week) ?? {
      input: [],
      output: [],
      date: row.date,
    };
    if (row.commodity === query.inputCommodity) entry.input.push(row.modalPrice);
    if (row.commodity === query.outputCommodity) entry.output.push(row.modalPrice);
    if (row.date < entry.date) entry.date = row.date;
    weekly.set(week, entry);
  });
  const weekNumbers = [...weekly.keys()].sort((a, b) => a - b);
  const overlapping = weekNumbers
    .map((week) => weekly.get(week)!)
    .filter((entry) => entry.input.length && entry.output.length)
    .map((entry) => ({
      date: entry.date,
      inputPrice: mean(entry.input),
      outputPrice: mean(entry.output),
    }))
    .sort((a, b) => a.date.localeCompare(b.date));
  let bestLag = 0;
  let bestCorrelation: number | null = null;
  let bestPairs: Array<{
    date: string;
    inputPrice: number;
    outputPrice: number;
  }> = [];
  for (let lag = 0; lag <= 8; lag += 1) {
    const pairs: Array<{
      date: string;
      inputPrice: number;
      outputPrice: number;
    }> = [];
    weekNumbers.forEach((week) => {
      const input = weekly.get(week);
      const output = weekly.get(week + lag);
      if (input?.input.length && output?.output.length) {
        pairs.push({
          date: input.date,
          inputPrice: mean(input.input),
          outputPrice: mean(output.output),
        });
      }
    });
    const inputs = pairs.map((point) => point.inputPrice);
    const outputs = pairs.map((point) => point.outputPrice);
    const correlation = pearsonCorrelation(inputs, outputs);
    if (
      correlation !== null &&
      (bestCorrelation === null ||
        Math.abs(correlation) > Math.abs(bestCorrelation))
    ) {
      bestCorrelation = correlation;
      bestLag = lag;
      bestPairs = pairs;
    }
  }
  const illustrative = selected.some((row) => row.dataSource === "illustrative");
  const distinctPair = query.inputCommodity !== query.outputCommodity;
  const available =
    distinctPair && !illustrative && bestPairs.length >= 26;
  return {
    inputCommodity: query.inputCommodity,
    outputCommodity: query.outputCommodity,
    state: query.state || null,
    status: available ? ("available" as const) : ("roadmap" as const),
    correlation: available ? bestCorrelation : null,
    lagDays: available ? bestLag * 7 : null,
    samples: bestPairs.length,
    points: available ? bestPairs : [],
    note: available
      ? "Lagged correlation is an association only, not evidence that one commodity price causes another."
      : !distinctPair
        ? "Choose two different commodities to compare price transmission."
        : "Transmission is shown only after both real commodities have at least 26 overlapping weekly observations. Illustrative values do not enable this analysis.",
    isIllustrative: illustrative,
  };
}

export function assistantAnswer(
  question: string,
  language: "en" | "hi" | "kn",
  rows: Observation[],
  commodity?: string | null,
  state?: string | null,
) {
  const lower = question.toLowerCase();
  const intents = [
    "latest price",
    "forecast",
    "risk and volatility",
    "seasonality",
    "price opportunity",
    "processing scenario",
    "data coverage",
  ];
  let intent = "help";
  if (/forecast|predict|भविष्य|ಅಂದಾಜು/.test(lower)) intent = "forecast";
  else if (/risk|volatil|ಅಪಾಯ|जोखिम/.test(lower)) intent = "risk and volatility";
  else if (/season|खरीफ|रबी|ಖಾರಿಫ್|ರಬಿ/.test(lower)) intent = "seasonality";
  else if (/opportunity|trend|ಅವಕಾಶ|मौका/.test(lower)) intent = "price opportunity";
  else if (/processing|margin|cost|ಸಂಸ್ಕರಣೆ|लागत/.test(lower)) intent = "processing scenario";
  else if (/coverage|dataset|data|upload|file|ಮಾಹಿತಿ|ಡೇಟಾ|डेटा/.test(lower)) intent = "data coverage";
  else if (/price|mandi|भाव|ಬೆಲೆ|ದರ/.test(lower)) intent = "latest price";

  const selected = filterObservations(rows, {
    commodity: commodity || undefined,
    state: state || undefined,
  });
  const latest = [...selected].sort((a, b) => b.date.localeCompare(a.date))[0];
  const illustrative = selected.some((row) => row.dataSource === "illustrative");
  const priceText = latest
    ? `${latest.commodity}: ₹${latest.modalPrice.toLocaleString("en-IN")} ${latest.unit}, ${latest.market}, ${latest.state}, ${latest.date}${illustrative ? " (illustrative preview, not an official quote)" : ""}.`
    : "";
  const en: Record<string, string> = {
    "latest price": latest ? priceText : "No matching price records are available. Import a dataset or change the crop and state.",
    forecast: "Use Forecast to compare the moving-average baseline with the fitted trend regression. The interval describes uncertainty; this is not a guaranteed price.",
    "risk and volatility": "Use Risk to compare recent price movement, volatility, the fitted 14-day trend change, and coverage. Risk is a price-signal summary, not a profit estimate.",
    seasonality: "Use Seasonality to compare Kharif, Rabi, and Zaid patterns from the selected history. A historical pattern does not predict what will happen next.",
    "price opportunity": "Use Opportunity to rank the selected state's crops for stability or recent price trend. The indicators show the evidence used; a high price is not the same as high profit.",
    "processing scenario": "Use Processing to change raw price, output yield, output price, and costs. Every result is a hypothetical gross margin, not observed profitability or net profit.",
    "data coverage": illustrative ? "The current screen uses illustrative preview data only. Import an AGMARKNET CSV and review date range, state/market coverage, arrivals, and price units before relying on results." : "Review Data audit for the imported file's commodity, state, market, date, arrivals, and unit coverage. Short histories are marked and are not treated as forecast-ready.",
    help: "I can help with latest price, forecast method, risk, seasonality, price opportunity, processing assumptions, or dataset coverage. Choose a crop and state for a more specific answer.",
  };
  const hi: Record<string, string> = {
    "latest price": latest ? `नवीनतम रिकॉर्ड: ${priceText}` : "इस फसल और राज्य के लिए कोई कीमत रिकॉर्ड नहीं है। डेटा आयात करें या चयन बदलें।",
    forecast: "Forecast में चल औसत आधार-रेखा और फिट किए गए ट्रेंड रिग्रेशन की तुलना करें। अंतराल अनिश्चितता दिखाता है; यह निश्चित कीमत नहीं है।",
    "risk and volatility": "Risk में हाल का बदलाव, अस्थिरता, 14-दिन का ट्रेंड बदलाव और डेटा कवरेज देखें। यह कीमत संकेत है, लाभ का अनुमान नहीं।",
    seasonality: "Seasonality में चयनित इतिहास के Kharif, Rabi और Zaid पैटर्न देखें। ऐतिहासिक पैटर्न भविष्यवाणी नहीं है।",
    "price opportunity": "Opportunity में स्थिरता या हाल के कीमत ट्रेंड के आधार पर फसलें क्रमबद्ध करें। संकेतक साक्ष्य बताते हैं; ऊँची कीमत का अर्थ अधिक लाभ नहीं है।",
    "processing scenario": "Processing में कच्चे माल की कीमत, उपज, उत्पाद कीमत और लागत बदलें। परिणाम काल्पनिक सकल मार्जिन है, वास्तविक लाभ या शुद्ध लाभ नहीं।",
    "data coverage": illustrative ? "यह स्क्रीन केवल उदाहरण डेटा दिखाती है। AGMARKNET CSV आयात कर तारीख, राज्य/बाज़ार, आवक और इकाइयों की जाँच करें।" : "Data audit में आयात की गई फसल, राज्य, बाज़ार, तारीख, आवक और इकाई कवरेज देखें।",
    help: "मैं नवीनतम कीमत, पूर्वानुमान विधि, जोखिम, मौसमी पैटर्न, कीमत अवसर, प्रसंस्करण मान्यताओं और डेटा कवरेज में मदद कर सकता हूँ।",
  };
  const kn: Record<string, string> = {
    "latest price": latest ? `ಇತ್ತೀಚಿನ ದಾಖಲೆ: ${priceText}` : "ಈ ಬೆಳೆ ಮತ್ತು ರಾಜ್ಯಕ್ಕೆ ಬೆಲೆ ದಾಖಲೆಗಳಿಲ್ಲ. ಡೇಟಾ ಆಮದು ಮಾಡಿ ಅಥವಾ ಆಯ್ಕೆಯನ್ನು ಬದಲಿಸಿ.",
    forecast: "Forecast ನಲ್ಲಿ ಚಲಿಸುವ ಸರಾಸರಿ ಮೂಲಮಾದರಿ ಮತ್ತು ಹೊಂದಿಸಿದ ಟ್ರೆಂಡ್ ರಿಗ್ರೆಷನ್ ಹೋಲಿಸಿ. ಅಂತರವು ಅನಿಶ್ಚಿತತೆಯನ್ನು ತೋರಿಸುತ್ತದೆ; ಇದು ಖಚಿತ ಬೆಲೆಯಲ್ಲ.",
    "risk and volatility": "Risk ನಲ್ಲಿ ಇತ್ತೀಚಿನ ಬದಲಾವಣೆ, ಅಸ್ಥಿರತೆ, 14 ದಿನದ ಟ್ರೆಂಡ್ ಬದಲಾವಣೆ ಮತ್ತು ಡೇಟಾ ವ್ಯಾಪ್ತಿ ನೋಡಿ. ಇದು ಬೆಲೆ ಸೂಚನೆ ಮಾತ್ರ, ಲಾಭದ ಅಂದಾಜಲ್ಲ.",
    seasonality: "Seasonality ನಲ್ಲಿ ಆಯ್ದ ಇತಿಹಾಸದ ಖಾರಿಫ್, ರಬಿ ಮತ್ತು ಜೈದ್ ಮಾದರಿಗಳನ್ನು ಹೋಲಿಸಿ. ಹಿಂದಿನ ಮಾದರಿ ಭವಿಷ್ಯದ ಖಾತರಿಯಲ್ಲ.",
    "price opportunity": "Opportunity ಯಲ್ಲಿ ಸ್ಥಿರತೆ ಅಥವಾ ಇತ್ತೀಚಿನ ಬೆಲೆ ಟ್ರೆಂಡ್ ಆಧರಿಸಿ ಬೆಳೆಗಳನ್ನು ಕ್ರಮಗೊಳಿಸಿ. ಸೂಚಕಗಳು ಬಳಸಿದ ಸಾಕ್ಷ್ಯವನ್ನು ತೋರಿಸುತ್ತವೆ; ಹೆಚ್ಚು ಬೆಲೆ ಎಂದರೆ ಹೆಚ್ಚು ಲಾಭವಲ್ಲ.",
    "processing scenario": "Processing ನಲ್ಲಿ ಕಚ್ಚಾ ಬೆಲೆ, ಉತ್ಪಾದನೆ, ಉತ್ಪನ್ನ ಬೆಲೆ ಮತ್ತು ವೆಚ್ಚಗಳನ್ನು ಬದಲಿಸಿ. ಫಲಿತಾಂಶ ಕಾಲ್ಪನಿಕ ಒಟ್ಟು ಮಾರ್ಜಿನ್ ಮಾತ್ರ, ನೈಜ ಅಥವಾ ನಿವ್ವಳ ಲಾಭವಲ್ಲ.",
    "data coverage": illustrative ? "ಈ ಪರದೆಯಲ್ಲಿ ಉದಾಹರಣೆ ಡೇಟಾ ಮಾತ್ರ ಇದೆ. AGMARKNET CSV ಆಮದು ಮಾಡಿ ದಿನಾಂಕ, ರಾಜ್ಯ/ಮಾರುಕಟ್ಟೆ, ಆಗಮನ ಮತ್ತು ಘಟಕಗಳನ್ನು ಪರಿಶೀಲಿಸಿ." : "ಆಮದು ಮಾಡಿದ ಬೆಳೆ, ರಾಜ್ಯ, ಮಾರುಕಟ್ಟೆ, ದಿನಾಂಕ, ಆಗಮನ ಮತ್ತು ಘಟಕ ವ್ಯಾಪ್ತಿಯನ್ನು Data audit ನಲ್ಲಿ ಪರಿಶೀಲಿಸಿ.",
    help: "ಇತ್ತೀಚಿನ ಬೆಲೆ, ಮುನ್ಸೂಚನೆ ವಿಧಾನ, ಅಪಾಯ, ಋತುಮಾನ, ಬೆಲೆ ಅವಕಾಶ, ಸಂಸ್ಕರಣೆಯ ಊಹೆಗಳು ಮತ್ತು ಡೇಟಾ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಸಹಾಯ ಮಾಡಬಹುದು.",
  };
  const dictionary = language === "hi" ? hi : language === "kn" ? kn : en;
  return {
    intent,
    answer: dictionary[intent] ?? dictionary.help,
    supportedIntents: intents,
    isIllustrative: illustrative,
  };
}

export function calculateScenario(input: {
  commodity: string;
  rawPrice: number;
  outputYield: number;
  outputPrice: number;
  processingCost: number;
  otherCost: number;
  rawPriceChangePercent: number;
  outputPriceChangePercent: number;
  costChangePercent: number;
}) {
  const baselineGrossMargin =
    input.outputYield * input.outputPrice -
    input.rawPrice -
    input.processingCost -
    input.otherCost;
  const scenarioRawPrice =
    input.rawPrice * (1 + input.rawPriceChangePercent / 100);
  const scenarioOutputPrice =
    input.outputPrice * (1 + input.outputPriceChangePercent / 100);
  const scenarioCosts =
    (input.processingCost + input.otherCost) *
    (1 + input.costChangePercent / 100);
  const scenarioGrossMargin =
    input.outputYield * scenarioOutputPrice - scenarioRawPrice - scenarioCosts;
  return {
    commodity: input.commodity,
    rawPrice: input.rawPrice,
    baselineGrossMargin: Math.round(baselineGrossMargin * 100) / 100,
    scenarioGrossMargin: Math.round(scenarioGrossMargin * 100) / 100,
    marginChange:
      Math.round((scenarioGrossMargin - baselineGrossMargin) * 100) / 100,
    unit: "₹ per quintal of raw input",
    assumptions: [
      "User-entered yield, output price, processing cost, and other cost are assumptions, not verified observations.",
      "Raw price is not a net profit calculation; financing, taxes, losses, and other costs may be excluded.",
      `Scenario changes: raw ${input.rawPriceChangePercent}%, output price ${input.outputPriceChangePercent}%, costs ${input.costChangePercent}%.`,
    ],
  };
}
